# Write 4 examples of expressions using each of the operations: `+`, `-`, `/`, and `%`.
# Print out the result of your expressions using `puts`. 
# Be sure to test your work by running your code with by typing `ruby 01_numbers_exercise_1.rb` in your terminal.

# Example:
# puts 4 + 2.5   # 6.5

# Write 4 more expressions:

puts 0.25 - 0.75
puts 3.0 / 4.0
puts -9 + 5
puts -81 - 3