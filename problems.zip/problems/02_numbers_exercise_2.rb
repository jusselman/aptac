# Write 6 comparison expressions using each of the operations: `==`, `!=`, `<`, `>`, `<=`, `>=`. 
# Print out the result of your expressions using `puts`. 
# Be sure to test your work by running your code with by typing `ruby 02_numbers_exercise_2.rb` in your terminal.

# Example:
# puts 4 == 4       # true

# Write 6 more expressions below:
puts 5 != 6
puts 9999 > 11
puts 16 < 8 # I made it false on purpose, tryin' to mix it up
puts 3.14 >= 3.13
puts 0 == 0
puts 0.11111111111 <= 0.1111111112