# Write 3 expressions using each of string operations: `+` (concatenation), `.length`, and `[]` (indexing).
# Print out the result of your expressions using `puts`. Be sure to test your work by running your code!

# Example:
puts "Hello " + "World"

# Write 3 more expressions below:
puts 'check ' + 'out ' + 'these ' + 'sick ' + 'concat skills.'
puts 'Did you guys want ' + 'three of ' + 'each of these?'
puts '4 ' + '4 ' + '= ' + '8.'

puts 'This is a string'.length
puts 'This TOOO!!!!!'.length
puts '3745893'.length

puts '3.14159265'[5]
puts 'STRINGIN'[3]
puts 'length - 1 gives final index!'[0]