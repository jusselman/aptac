# Write 4 examples or expressions using each of the operations: `&&`, `||`, `!`. 
# Print out the result of your expressions using `puts`. Be sure to test your work by running your code!

# Example:
# puts false || false   # false

# Write 4 more expressions below:

puts true || false
puts true || true
puts false || true
puts false || false

puts true && true
puts false && true
puts true && false
puts false && false

puts !(false && false)
puts !(true && true)
puts !(false || false)
puts !(true || true)
