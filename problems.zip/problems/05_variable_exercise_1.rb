# Time to practice variables! Follow the comments for instructions.

# 1. Declare a variable named `firstName` and assign it your first name as a string:
firstName = 'Joshua'


# 2. Declare a variable named `lastName` and assign it your last name as a string:
lastName = 'Usselman'


# 3. Declare a variable named `fullName` and assign it the concatenation of
# your `firstName` and `lastName`. Be sure to put a space between your
# first and last names:
fullName = firstName + " " + lastName

# 4. print out the `fullName` variable:
puts fullName
