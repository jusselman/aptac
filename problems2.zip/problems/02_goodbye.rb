# Write a method `goodbye(name)` that takes in a string name and returns a string saying bye to that name. 
# See the example calls.

def goodbye(name)
  puts "Goodbye " + name
end

puts goodbye("Shakira")   # => "Bye Daniel."
puts goodbye("Rhianna")     # => "Bye Mark."
puts goodbye("Beyonce")  # => "Bye Beyonce."
